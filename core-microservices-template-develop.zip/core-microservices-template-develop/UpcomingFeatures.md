# Upcoming Features:

## Phase 2:      
   * Rename repo and servicename to core-microservices-template
   * Tables and seed data creation as part of the migration in the source (rather than the separate SQL file)
   * Unit test case coverage - target for 100%
   * Swagger and OpenAPI Documentation
   * transfer this repo to 3Pillar Global Open Source (handle 3pillarlabs)

## Phase 3:
   * Visual Studio Template
   * Create Idserver Application and Setup
   * Idserver integration in CustomServiceTemplate
