exports.BASE_URL = "http://localhost:28601/service/"
exports.API_KEY = "67cd910a-6a6d-4cb3-b57b-92f7a4dee9c2"