﻿
namespace Core.Services.Entities
{
    public class VersionDocument
    {
        public string Url { get; set; }
        public string Status { get; set; }
    }
}
