﻿
namespace Core.Services.Entities
{ 
    public enum VersionStatus
    {
        Deprecated,
        Live,
        Preview
    }
}
