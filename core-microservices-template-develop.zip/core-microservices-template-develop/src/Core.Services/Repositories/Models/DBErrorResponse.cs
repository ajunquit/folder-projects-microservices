﻿
namespace Hypergate.Invoices.Repositories.Models
{
    public class DBErrorResponse
    {
        public string ErrorMessage { get; set; }
        public string MessageId { get; set; }
    }
}
