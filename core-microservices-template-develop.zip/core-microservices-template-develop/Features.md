# This .NetCore Microservice Application contains below features:
* Authentication (Basic Key)
* Exception handling
* Database connectivity
* Database script
* Docker
* Logging: 
	 1. Docker logging (Kitematic)
* Monitoring:
	 1. NewRelic
* Tests:
	 1. Cucumber Automation Tests
	 2. Unit Tests with Mock

