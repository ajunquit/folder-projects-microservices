Course ".NET Core Microservices: Transitioning monolithic architectures using microservices with .NET Core": https://www.safaribooksonline.com/videos/net-core-microservices/9781788626415



Actio.Api -> API gateway
Actio.Commn -> Messaging bus (RabbitMQ)
Actio.Services.Activities -> Activities service
Actio.Services.Identity -> Identity services


docker run -d -p 27017:27017 mongo

https://jwt.io/introduction/