namespace Actio.Common.Events
{
    /// 
    public interface IEvent
    {

    }
}