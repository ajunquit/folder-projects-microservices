namespace Actio.Common.Commands
{
    /// Marker interface
    public interface ICommand
    {

    }
}