namespace Actio.Common.Services
{
    public interface IServiceHost
    {
        
    }
}