namespace Actio.Common.RabbitMq
{
    using RawRabbit;
    using RawRabbit.Configuration;

    public class RabbitMqOptions  : RawRabbitConfiguration
    {

    }

    //https://rawrabbit.readthedocs.io
}